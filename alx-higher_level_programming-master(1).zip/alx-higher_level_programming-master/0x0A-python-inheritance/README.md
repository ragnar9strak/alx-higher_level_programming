0x0A-python-inheritance
