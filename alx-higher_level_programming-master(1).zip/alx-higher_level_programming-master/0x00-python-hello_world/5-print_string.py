#!/usr/bin/python3
str = "Holberton School"
print(str + str + str)
print(str[:9])
