#!/usr/bin/python3
number = 98
<<<<<<< HEAD
print(f"{number} Battery street")

=======
print(f"{number:d} Battery street")
>>>>>>> a98ec55e3ab81a44ba69478e070931fb64622a54
