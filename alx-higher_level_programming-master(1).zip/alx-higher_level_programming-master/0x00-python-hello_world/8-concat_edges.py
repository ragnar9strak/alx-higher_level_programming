#!/usr/bin/python3
str1 = "object-oriented"
str2 = " programming with Python"
print(str1 + str2)
