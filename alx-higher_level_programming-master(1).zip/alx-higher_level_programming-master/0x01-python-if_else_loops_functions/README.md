0x01-python-if else loops functions
