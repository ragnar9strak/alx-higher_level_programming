#!/usr/bin/python3
def mutiply_list_map(my_list=[], number=0):
    return (list(map(lambda element: element * number, my_list)))
