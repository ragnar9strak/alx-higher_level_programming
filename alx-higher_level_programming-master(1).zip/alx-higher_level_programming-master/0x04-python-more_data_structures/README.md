## 0x04. Python - More Data Structures: Set, Dictionary

Set and Dictionary

# Tasks

[0. Squared simple]()
