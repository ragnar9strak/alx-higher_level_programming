-- count and display number of records where id=89
-- in first_table
SELECT COUNT(id) FROM first_table WHERE id = 89;
