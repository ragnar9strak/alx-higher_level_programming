-- print full description of the table first_table
-- from the database hbtn_0c_0
SHOW CREATE TABLE first_table;
