-- computes score average of all records in the second_table
SELECT AVG(score) AS average FROM second_table;
