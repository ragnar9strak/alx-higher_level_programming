-- list all the tables of database passed
-- as argument of mysql command
SHOW TABLES;
