-- removes all records where score is <= 5 from
DELETE FROM second_table WHERE score <= 5;
