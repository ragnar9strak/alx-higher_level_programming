0x05. Python - Exceptions
