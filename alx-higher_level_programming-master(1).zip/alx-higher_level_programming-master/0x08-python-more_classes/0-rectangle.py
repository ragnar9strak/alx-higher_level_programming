#!/usr/bin/python3
"""0-rectangle, built for Holberton project 0x08 task 0.
"""


class Rectangle:
    """Empty class per task instructions, will be built upon in later tasks.
    """
    pass
